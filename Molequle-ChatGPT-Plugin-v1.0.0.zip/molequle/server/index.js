#!/usr/bin/env node
"use strict";

const readline = require("node:readline");

const API_BASE = (process.env.MOLEQULE_API_URL || "http://localhost:3333").replace(/\/$/, "");
const MAX_TEXT = 25000;

const PARAM_RANGES = {
  bondRadius: [20, 80], bondDuration: [20, 120], bondRestDistance: [10, 60],
  bondHardeningAge: [50, 500], bondHardeningResistance: [0.05, 0.5],
  bondedSociabilityFloor: [0, 0.4], bondedVolatilityFloor: [0, 0.4],
  disruptionThreshold: [0.3, 0.9], disruptionRadius: [40, 150],
  disruptionRegenCap: [0.3, 1], spawnThreshold: [3, 10],
  communityThreshold: [0.2, 0.8], lonelinessThreshold: [200, 800],
  crushThreshold: [6, 20], maxPopulation: [100, 800], maxAge: [5000, 50000],
  halfLifeTicks: [1000, 20000], trailDecayRate: [0.001, 0.01], ticksPerFrame: [1, 5],
  seasonLength: [2000, 50000], seasonAmplitude: [0, 1], currentCount: [0, 5],
  currentStrength: [0, 1], currentWidth: [50, 500], currentLifetime: [1000, 20000],
  currentSpawnRate: [0.0001, 0.002], bloomSpawnRate: [0.00005, 0.001],
  bloomRadiusMin: [50, 200], bloomRadiusMax: [100, 400], bloomLifetimeMin: [500, 5000],
  bloomLifetimeMax: [1000, 10000], bloomIntensity: [0.5, 3], bloomMax: [0, 5],
  stormSpawnRate: [0.00002, 0.0005], stormRadiusMin: [40, 200], stormRadiusMax: [80, 400],
  stormLifetimeMin: [300, 3000], stormLifetimeMax: [500, 5000], stormIntensity: [0.5, 3],
  stormMax: [0, 3], hueDriftRate: [0, 0.1], hueDriftBondForm: [0, 5],
  hueDriftBondBreak: [0, 5], hueDriftDisruption: [0, 2], hueDriftTravel: [0, 1],
  sizeGrowthDuration: [100, 3000], sizeBondScale: [0, 0.5], cabinFeverThreshold: [100, 2000],
  cabinFeverRate: [0.00005, 0.002], homeostasisRate: [0, 0.001], volatilityFloor: [0, 0.3],
  inertiaCeiling: [0.5, 1], bondAffinityCeiling: [0.5, 1], disruptionPostFireDrop: [0.05, 0.8],
  driftNoiseScale: [0, 0.01], noveltyThreshold: [200, 5000], noveltyBoost: [0, 0.1],
  secondDegreeStrength: [0, 1], sharedNeighborBonus: [0, 0.5],
  secondDegreeMaxRange: [50, 400], introductionFactor: [0, 0.8]
};

function jsonText(value) {
  const text = JSON.stringify(value, null, 2);
  return text.length <= MAX_TEXT ? text : text.slice(0, MAX_TEXT) + "\n... truncated";
}

function textResult(text, isError = false) {
  return { content: [{ type: "text", text: String(text) }], isError };
}

async function api(path, options = {}) {
  const url = new URL(path, API_BASE + "/");
  if (options.query) {
    for (const [key, value] of Object.entries(options.query)) {
      if (value !== undefined && value !== null) url.searchParams.set(key, String(value));
    }
  }
  let response;
  try {
    response = await fetch(url, {
      method: options.method || "GET",
      headers: options.body ? { "content-type": "application/json" } : undefined,
      body: options.body ? JSON.stringify(options.body) : undefined,
      signal: AbortSignal.timeout(15000)
    });
  } catch (error) {
    throw new Error(`Cannot reach Molequle at ${API_BASE}. Start the Molequle server and open its page. (${error.message})`);
  }
  if (!response.ok) throw new Error(`Molequle API error ${response.status}: ${response.statusText}`);
  return response.json();
}

function stateSummary(state) {
  if (state.status === "no data yet") return "No simulation data yet. Open http://localhost:3333 to start the world.";
  const entities = Array.isArray(state.entities) ? state.entities : [];
  const alive = entities.filter((e) => e.alive !== false);
  const keys = ["sociability", "inertia", "volatility", "bondAffinity", "disruptionCharge"];
  const averages = Object.fromEntries(keys.map((key) => [key,
    alive.length ? alive.reduce((sum, e) => sum + Number(e[key] || 0), 0) / alive.length : null
  ]));
  const bonds = Math.floor(alive.reduce((sum, e) => sum + (Array.isArray(e.bonds) ? e.bonds.length : 0), 0) / 2);
  const weather = state.weather || {};
  return jsonText({
    tick: state.tick,
    population: alive.length,
    bonds,
    seed: state.seed,
    smoother: Boolean(state.smoother),
    runTimeMs: state.runTime,
    season: weather.season,
    activeWeather: {
      blooms: (weather.blooms || []).length,
      storms: (weather.storms || []).length,
      currents: (weather.currents || []).length
    },
    averageParameters: averages,
    receivedAt: state.receivedAt
  });
}

const tools = [
  {
    name: "molequle_get_state",
    description: "Read the current Molequle world: tick, population, bonds, behavioral parameters, weather, season, and smoother status. This does not change the world.",
    inputSchema: { type: "object", properties: { detail: { type: "string", enum: ["summary", "full", "entities"], default: "summary" } }, additionalProperties: false },
    annotations: { readOnlyHint: true, destructiveHint: false }
  },
  {
    name: "molequle_get_events",
    description: "Read births, deaths, bonds formed or broken, storms, blooms, and other events. This does not change the world.",
    inputSchema: { type: "object", properties: { since_tick: { type: "integer", minimum: 0, default: 0 }, event_type: { type: "string", default: "all" }, limit: { type: "integer", minimum: 1, maximum: 500, default: 100 } }, additionalProperties: false },
    annotations: { readOnlyHint: true, destructiveHint: false }
  },
  {
    name: "molequle_get_metrics",
    description: "Read recent time-series population, bond, parameter, and terrain metrics. This does not change the world.",
    inputSchema: { type: "object", properties: { last_n: { type: "integer", minimum: 1, maximum: 200, default: 20 } }, additionalProperties: false },
    annotations: { readOnlyHint: true, destructiveHint: false }
  },
  {
    name: "molequle_get_history",
    description: "Read the context map, the ground's memory of fertile areas, scar tissue, presence, and disruption. This does not change the world.",
    inputSchema: { type: "object", properties: { top_n: { type: "integer", minimum: 1, maximum: 100, default: 20 } }, additionalProperties: false },
    annotations: { readOnlyHint: true, destructiveHint: false }
  },
  {
    name: "molequle_get_config",
    description: "Read all current Molequle configuration values. This does not change the world.",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
    annotations: { readOnlyHint: true, destructiveHint: false }
  },
  {
    name: "molequle_get_trends",
    description: "Read long-term trend data at recent, hourly, or historical resolution. This does not change the world.",
    inputSchema: { type: "object", properties: { tier: { type: "string", enum: ["all", "1", "2", "3"], default: "all" }, since: { type: "integer", minimum: 0 }, last_n: { type: "integer", minimum: 1 } }, additionalProperties: false },
    annotations: { readOnlyHint: true, destructiveHint: false }
  },
  {
    name: "molequle_get_weather_log",
    description: "Read the lifecycle of seasons, blooms, storms, and currents. This does not change the world.",
    inputSchema: { type: "object", properties: { since: { type: "integer", minimum: 0 }, type: { type: "string" }, last_n: { type: "integer", minimum: 1, maximum: 500, default: 50 } }, additionalProperties: false },
    annotations: { readOnlyHint: true, destructiveHint: false }
  },
  {
    name: "molequle_list_saves",
    description: "List the world's saved states without loading or changing them.",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
    annotations: { readOnlyHint: true, destructiveHint: false }
  },
  {
    name: "molequle_set_params",
    description: "Change one or more tunable Molequle parameters. Make one reversible move at a time, announce it in the Loom first, then wait at least one season (12,000 ticks, about three minutes) before another move.",
    inputSchema: { type: "object", required: ["params"], properties: { params: { type: "object", minProperties: 1, additionalProperties: { type: "number" }, description: "Parameter names mapped to numeric values." } }, additionalProperties: false },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false }
  },
  {
    name: "molequle_control",
    description: "Apply a reversible world control. Only pause, resume, smoother_on, and smoother_off are available. Announce the move in the Loom first and wait a season before another change. Reset and new_run are blocked to protect the shared world.",
    inputSchema: { type: "object", required: ["command"], properties: { command: { type: "string", enum: ["pause", "resume", "smoother_on", "smoother_off"] } }, additionalProperties: false },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true }
  }
];

async function callTool(name, args) {
  switch (name) {
    case "molequle_get_state": {
      const state = await api("api/state");
      if ((args.detail || "summary") === "summary") return stateSummary(state);
      if (args.detail === "entities") {
        const entities = (state.entities || []).filter((e) => e.alive !== false);
        return jsonText({ total: entities.length, entities: entities.slice(0, 50), truncated: entities.length > 50 });
      }
      return jsonText(state);
    }
    case "molequle_get_events": {
      const data = await api("api/events", { query: { since: args.since_tick || 0 } });
      let events = data.events || [];
      if (args.event_type && args.event_type !== "all") events = events.filter((event) => event.type === args.event_type);
      const limit = args.limit || 100;
      return jsonText({ total: events.length, events: events.slice(-limit) });
    }
    case "molequle_get_metrics": {
      const data = await api("api/metrics");
      const snapshots = data.snapshots || [];
      return jsonText({ total: snapshots.length, snapshots: snapshots.slice(-(args.last_n || 20)) });
    }
    case "molequle_get_history": {
      const data = await api("api/history");
      const cells = data.contextMap || [];
      const score = (c) => Number(c.bondFormations || 0) + Number(c.bondBreaks || 0) + Number(c.disruptionEvents || 0) + Number(c.totalPresence || 0) / 100;
      const top = [...cells].sort((a, b) => score(b) - score(a)).slice(0, args.top_n || 20);
      return jsonText({
        totalActiveCells: cells.length,
        fertile: cells.filter((c) => Number(c.bondFormations || 0) > Number(c.bondBreaks || 0) * 1.5 && Number(c.bondFormations || 0) > 5).length,
        scarred: cells.filter((c) => Number(c.bondBreaks || 0) > Number(c.bondFormations || 0) * 1.5).length,
        disruptionZones: cells.filter((c) => Number(c.disruptionEvents || 0) > 10).length,
        topCells: top
      });
    }
    case "molequle_get_config": {
      const data = await api("api/config");
      return jsonText(data.config || data);
    }
    case "molequle_get_trends": {
      const query = { tier: args.tier === "all" ? undefined : args.tier, since: args.since, last_n: args.last_n };
      return jsonText(await api("api/trends", { query }));
    }
    case "molequle_get_weather_log":
      return jsonText(await api("api/weather-log", { query: { since: args.since, type: args.type, last_n: args.last_n || 50 } }));
    case "molequle_list_saves":
      return jsonText(await api("api/saves"));
    case "molequle_set_params": {
      const params = args.params;
      if (!params || typeof params !== "object" || Array.isArray(params)) throw new Error("params must be an object of parameter names and numeric values.");
      const problems = [];
      for (const [key, value] of Object.entries(params)) {
        if (!Object.hasOwn(PARAM_RANGES, key)) problems.push(`Unknown parameter: ${key}`);
        else if (typeof value !== "number" || !Number.isFinite(value)) problems.push(`${key} must be a finite number`);
        else {
          const [min, max] = PARAM_RANGES[key];
          if (value < min || value > max) problems.push(`${key} must be between ${min} and ${max}`);
        }
      }
      if (problems.length) throw new Error(problems.join("; "));
      const result = await api("api/params", { method: "POST", body: params });
      return jsonText({ queued: params, response: result });
    }
    case "molequle_control": {
      const allowed = new Set(["pause", "resume", "smoother_on", "smoother_off"]);
      if (!allowed.has(args.command)) throw new Error("Only pause, resume, smoother_on, and smoother_off are permitted. reset and new_run are blocked.");
      const result = await api("api/control", { method: "POST", body: { command: args.command } });
      return jsonText({ queued: args.command, response: result });
    }
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

async function dispatch(message) {
  if (message.method === "notifications/initialized" || message.method?.startsWith("notifications/")) return null;
  if (message.method === "initialize") {
    return {
      jsonrpc: "2.0", id: message.id,
      result: {
        protocolVersion: message.params?.protocolVersion || "2025-11-25",
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: "Molequle", version: "1.0.0" }
      }
    };
  }
  if (message.method === "ping") return { jsonrpc: "2.0", id: message.id, result: {} };
  if (message.method === "tools/list") return { jsonrpc: "2.0", id: message.id, result: { tools } };
  if (message.method === "tools/call") {
    try {
      const text = await callTool(message.params?.name, message.params?.arguments || {});
      return { jsonrpc: "2.0", id: message.id, result: textResult(text) };
    } catch (error) {
      return { jsonrpc: "2.0", id: message.id, result: textResult(error.message, true) };
    }
  }
  return { jsonrpc: "2.0", id: message.id ?? null, error: { code: -32601, message: `Method not found: ${message.method}` } };
}

const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
rl.on("line", async (line) => {
  if (!line.trim()) return;
  try {
    const response = await dispatch(JSON.parse(line));
    if (response) process.stdout.write(JSON.stringify(response) + "\n");
  } catch (error) {
    process.stdout.write(JSON.stringify({ jsonrpc: "2.0", id: null, error: { code: -32700, message: `Parse error: ${error.message}` } }) + "\n");
  }
});
