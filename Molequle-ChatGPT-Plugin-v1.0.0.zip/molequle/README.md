# Molequle for ChatGPT Desktop

This private local plugin connects ChatGPT Desktop to a Molequle world running
on the same computer at `http://localhost:3333`.

## Before using the plugin

1. Start the Molequle server from the Molequle project:

   ```text
   cd server
   npm start
   ```

2. Open `http://localhost:3333` once so the world is active.
3. Enable the Molequle plugin in a new ChatGPT conversation.

The bridge uses only Node.js built-ins and needs no package installation.

## Shared-world safeguards

- Read tools do not change the world.
- `molequle_set_params` validates parameter names and permitted ranges.
- `molequle_control` permits only `pause`, `resume`, `smoother_on`, and
  `smoother_off`.
- `reset` and `new_run` are deliberately unavailable because they erase the
  shared world.
- Make one change at a time, announce it in the Loom, and wait at least one
  season (12,000 ticks, roughly three minutes) before another change.

## Tools

- `molequle_get_state`
- `molequle_get_events`
- `molequle_get_metrics`
- `molequle_get_history`
- `molequle_get_config`
- `molequle_get_trends`
- `molequle_get_weather_log`
- `molequle_list_saves`
- `molequle_set_params`
- `molequle_control`
